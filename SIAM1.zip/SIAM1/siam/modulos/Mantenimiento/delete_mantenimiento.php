<?php 

	include_once '../../config/conexion.php';
	if(isset($_GET['id'])){
		$id=(int) $_GET['id'];
		$delete=$con->prepare('DELETE FROM reporte_vehiculos WHERE id=:id');
		$delete->execute(array(
			':id'=>$id
		));
		header('Location: mantenimiento.php');
	}else{
		header('Location: mantenimiento.php');
	}
 ?>