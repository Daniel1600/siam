<?php

    include_once '../../../config/conexion.php';
    
    if(isset($_POST['guardar'])) {
        $cantidad=$_POST['cantidad'];
        $descripcion=$_POST['descripcion'];
        $tipo=$_POST['tipo'];
        
        if(!empty($cantidad) && !empty($descripcion) && !empty($tipo)) {
            if(!filter_var($cantidad,FILTER_SANITIZE_STRIPPED)){
                echo "<script>alert('Te falto introducir la cantidad')</script>";
            }else{
                $consulta_insert=$con->prepare('INSERT INTO solicitar (cantidad,descripcion,tipo)VALUES(:cantidad,:descripcion,:tipo)');
                $consulta_insert->execute(array(
                ':cantidad'=>$cantidad,
                ':descripcion'=>$descripcion,
                ':tipo'=>$tipo                
                ));
                
                header('Location: ../solicitados.php');
            }
        }else{
            echo "<script>alert('Los campos estan vacios o te falto rellenar uno')</script>";
        }
        
    }


?>