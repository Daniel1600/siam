<?php 

	include_once '../../../config/conexion.php';
	if(isset($_GET['id'])){
		$id=(int) $_GET['id'];
		$delete=$con->prepare('DELETE FROM repuestos WHERE id=:id');
		$delete->execute(array(
			':id'=>$id
		));
		header('Location: ../disponibles.php');
	}else{
		header('Location: ../disponibles.php');
	}
 ?>