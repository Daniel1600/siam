<?php
	include_once '../../config/conexion.php';

	$sentencia_select=$con->prepare('SELECT *FROM disponibilidad ORDER BY id ASC LIMIT 20');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT *FROM disponibilidad WHERE id_vehiculo LIKE :campo OR placa LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SIAM | Sistema de Informacion y Analisis de Mantenimiento</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../css/font-awesome.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../../css/diagnostico.css"><!-- css de diagnostico--->
    <link rel="stylesheet" href="../../css/_all-skins.min.css">
    <link rel="apple-touch-icon" href="../../img/apple-touch-icon.png">

  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <header class="main-header">

        <!-- Logo -->
        <a href="../../principal.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>SI</b>AM</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>SIAM</b></span>
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Navegación</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <small class="bg-red">Activo</small>
                  <span class="hidden-xs">Usuarios</span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    
                    <p>
                      Estamos trabajando para darte una mejor experiencia.
                      <small>Aprendices Sena</small>
                    </p>
                  </li>
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <!--
                     <div class="pull-left">
                      <a href="#" class="btn btn-default btn-flat">Perfil</a>
                    </div>
                    --->
                    <div class="pull-right">
                      <a href="../../salir.php" class="btn btn-default btn-flat">Cerrar sesión</a>
                    </div>
                  </li>
                </ul>
              </li>
              
            </ul>
          </div>

        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
                    
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
            <li class="treeview">
              <a href="../../principal.php">
                <i class="fa fa-home"></i>
                <span>Inicio</span>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Diagnóstico del vehículo</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="disponible.php"><i class="fa fa-signal"></i> Disponibilidad</a></li>
                <li><a href="../Mantenimiento/mantenimiento.php"><i class="fa fa-key"></i> Mantenimiento</a></li>
                <li><a href="../Diagnosticovehiculo/programacionMantenimiento.php"><i class="fa fa-keyboard-o"></i> Programar mantenimiento</a></li>
              </ul>
            </li>
            
            <li class="treeview">
              <a href="../Mantenimiento/mantenimiento.php">
                <i class="fa fa-key"></i>
                <span>Mantenimiento</span>
              </a>
            </li>
            
             <li class="treeview">
              <a href="../vehiculos/vehiculos.php">
                <i class="fa fa-car"></i>
                <span>Vehículos</span>
              </a>
            </li>
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-spinner"></i>
                <span>Repuestos</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href=""><i class="fa fa-chevron-circle-right"></i> Solicitados</a></li>
                <li><a href=""><i class="fa fa-tags"></i> Proximos</a></li>
                <li><a href=""><i class="fa fa-archive"></i> Nuevos repuestos</a></li>
              </ul>
            </li>
                       
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Acceso a usuarios</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="../configuracion/usuarios.php"><i class="fa fa-user"></i> Usuarios</a></li>
                
              </ul>
            </li>
             <li>
              <a href="#">
                <i class="fa fa-plus-square"></i> <span>Ayuda</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>
            <li>
              <a href="../acerca.php">
                <i class="fa fa-info-circle"></i> <span>Acerca Del Sistema</span>
              </a>
            </li>
                        
          </ul>
        </section>
        <!-- /.sidebar -->
        </aside>
        
       <!--Contenido-->
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
        <h2>SIAM | moviles disponibles para mantenimiento</h2>
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                <div class="box-header with-border">
                  <h4 class="box-title" style="font-size: 20px;">Listado de vehículos</h4>
                    <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  	<div class="row">
	                  	<div class="col-md-12">
		                          <!--Contenido-->
                                    <div class="contenedor">
		                        		<div class="barra_buscador">
			                                <form action="" class="formulario" method="post">
				                                <input type="text" name="buscar" placeholder="buscar id_vehículo o numero de placa" value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input_text">
				                                <input type="submit" class="btn" name="btn_buscar" value="Buscar">
				                                <a href="../../includes/disponibilidad/insert.php" class="btn btn_nuevo">Nuevo</a>
			                                </form>
		                                </div>
                                      <table>
                                          <tr class="head">
                                              <td>Id</td>
                                              <td>Id_vehículo</td>
                                              <td>Placa</td>
                                              <td>Modelo</td>
                                              <td>Fecha_matricula</td>
                                              <td>Estado</td>
                                              <td colspan="3">Acción</td>
                                          </tr>
                                          <?php foreach($resultado as $fila): ?>
                                             
                                            <tr>
                                                <td><?php echo $fila['id']; ?></td>
                                                <td><?php echo $fila['id_vehiculo']; ?></td>
                                                <td><?php echo $fila['placa']; ?></td>
                                                <td><?php echo $fila['modelo']; ?></td>
                                                <td><?php echo $fila['fecha_matricula']; ?></td>
                                                <td><?php echo $fila['estado']; ?></td>
                                                <td><a href="../../includes/disponibilidad/update.php?id=<?php echo $fila['id']; ?>" class="btn_update">Editar</a></td>
                                                <td><a href="../../includes/disponibilidad/delete.php?id=<?php echo $fila['id']; ?>" class="btn_delete">Eliminar</a></td>
                                                <td><a href="programacionMantenimiento.php?id=<?php echo $fila['id']; ?>" class="btn_programar">Programar</a></td>
                                            </tr>
                                          
                                          <?php endforeach?>
                                      </table>
                                    </div>  
		                          <!--Fin Contenido-->
                           </div>
                    </div>
                  		</div>
                  	</div><!-- /.row -->
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <!--Fin-Contenido-->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
        </div>
        <strong>Copyright © 2020 <a href=""></a>.</strong>  SIAM ALL RIGHTS RESERVED. LICENCIA AUTORIZADA PARA ESTE ES MI BUS.
      </footer>

      
    <!-- jQuery 2.1.4 -->
    <script src="../../js/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../js/app.min.js"></script>
    
  </body>
</html>