<?php 

	include_once '../../config/conexion.php';
	if(isset($_GET['id'])){
		$id=(int) $_GET['id'];
		$delete=$con->prepare('DELETE FROM usuarios WHERE id=:id');
		$delete->execute(array(
			':id'=>$id
		));
		header('Location: ../configuracion/usuarios.php');
	}else{
		header('Location: ../configuracion/usuarios.php');
	}
 ?>