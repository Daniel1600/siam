<?php 

    class Paciente {    
        
        private $id;    
        private $Placa;    
        private $Modelo;    
        private $Fecha_matricula;    
        private $Estado;        
        
        public function __construct($id,$placa,$modelo,$fecha,$estado) { 
            
            $this->Id=$id;
            $this->Placa=$placa;
            $this->Modelo=$modelo;
            $this->Fecha_matricula=$fecha;
            $this->Estado=$estado;
        
        }    
        
        public function obtenerId(){
            return $this->Id;    
        }    
        
        public function obtenerPlaca(){
            return $this->Placa;    
        }    
        
        public function obtenerModelo(){
            return $this->Modelo;    
        }    
        
        public function obtenerFecha_matricula(){        
            return $this->Fecha_matricula;    
        }    
        
        public function obtenerEstado(){        
            return $this->Estado;    
        } 
    }