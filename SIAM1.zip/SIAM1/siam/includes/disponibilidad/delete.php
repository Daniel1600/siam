<?php 

	include_once '../../config/conexion.php';
	if(isset($_GET['id'])){
		$id=(int) $_GET['id'];
		$delete=$con->prepare('DELETE FROM disponibilidad WHERE id=:id');
		$delete->execute(array(
			':id'=>$id
		));
		header('Location: ../../modulos/Diagnosticovehiculo/disponible.php');
	}else{
		header('Location: ../../modulos/Diagnosticovehiculo/disponible.php');
	}
 ?>