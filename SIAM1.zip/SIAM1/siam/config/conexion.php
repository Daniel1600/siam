<?php

$user = "root";
$password = "123456";
$database = "siam";

try {
    
    $con=new PDO('mysql:host=localhost;dbname='.$database,$user,$password);

}catch(PDOException $e) {
    echo("ERROR: ".$e->getMessage());
}




?>